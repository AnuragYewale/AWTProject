<?php
$con = mysqli_connect("localhost", "root", "","mca_proj");

// Check for connection success

if(!$con){
    die("connection to this database failed due to" . mysqli_connect_error());
}

$c_userid=$_GET['c_userid'];
$sql="DELETE FROM customer where c_userid='".$c_userid."';";
if($query=mysqli_query($con,$sql))
{
    echo "<script>alert('Customer record has deleted....');
    window.location.href = 'viewtotalusers.php';
    </script>";
}

?>
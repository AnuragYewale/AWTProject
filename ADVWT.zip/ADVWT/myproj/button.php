<!DOCTYPE html>
<head>
<style>
 .button{
 font-color:white;
 background:linear-gradient(135deg, #71b7e6, #9b59b6);
 border-radius: 5px;border: none;color: #fff;
 font-size: 14px;font-weight: 500;letter-spacing: 1px;cursor: pointer;
 height: 30px;margin: 35px 0;width: 80px;position:relative;
  left:360px;
 -moz-transform:rotate(90deg);
  }
</style>   
</head>                                                 


 <body>
 
 
 <button type="button"  class="button" value="Button" >Button
 </button>
   
  <button type="button" class="btn btn-primary" style="position:fixed;right:0px;top:135px;-moz-transform:rotate(90deg);
                                              background:linear-gradient(135deg, #71b7e6, #9b59b6);
                                                     border-radius: 5px;border: none;color:white;
                                                     font-size: 18px;font-weight: 500;letter-spacing: 1px;cursor: pointer;
                                                     height: 35px;width:100px;padding-left:9px;padding-top:2px;
                                                     ">Enquiry</button>
 
</body>
</html>
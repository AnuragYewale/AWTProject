<!DOCTYPE html> 
<head> <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Tour managment</title> 
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="bootstrap.css" rel='stylesheet' type='text/css'/>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="stylee.css">


</head> 
<body class="bgimg">
<div class="header-top">
  <!--container-->
   <div class="container">
    <div class="top-nav">
     <div class="logo">  
       <a href="" ><img class="logo" src="TWlogo.jpg" style="height:40px;padding:2px 10px;"></a> 
     </div>
    <div class="menu">
     <ul id="nav">
      <li><a href="index.php#section-1"  onclick="javascript:window.open('index.php#section-1','_self')"> Home</a></li>
      <li><a href="index.php#section-2"  onclick="javascript:window.open('index.php#section-2','_self')"> About</a></li>
      <li><a href="index.php#section-3"  onclick="javascript:window.open('index.php#section-3','_self')"> Gallery</a></li>
      <li><a href="index.php#section-5"   onclick="javascript:window.open('index.php#section-5','_self')"> User Login</a></li>					 
      <li><a href="admin/loginform.php"  onclick="javascript:window.open('index.php#section-1','_self')"> Admin Login</a></li>	
     </ul>
    </div>
   </div>
  </div>
<!--/container-->
</div>
</body>
</html>
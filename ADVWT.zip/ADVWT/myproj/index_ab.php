
<!DOCTYPE html> 
<head> <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Tour managment</title> 
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="bootstrap.css" rel='stylesheet' type='text/css'/>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="stylee.css">


</head> 
<body class="bgimg">
<div class="header-top">
		 <!--container-->
		  <div class="container">
			 <div class="top-nav">
			   <div class="logo">
              			 <a href="" ><img class="logo" src="TWlogo.jpg" style="height:40px;padding:2px 10px;"></a> 
					</div>
					<div class="menu">
		        			<ul id="nav">
						 <li><a href="index.php#section-1"  onclick="javascript:window.open('index.php#section-1','_self')"> Home</a></li>
						 <li><a href="index.php#section-2"  onclick="javascript:window.open('index.php#section-2','_self')"> About</a></li>
						 <li><a href="index.php#section-3"  onclick="javascript:window.open('index.php#section-3','_self')"> Gallery</a></li>
					
                                                  <li class="nav-item dropdown">
                                                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                  Contact Us
                                                  </a>
                                                  <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                  <a class="dropdown-item" href="userfeedback.php">Feedback</a>
                                                  <a class="dropdown-item" href="enquiry.php">Enquiry</a> </li> 

                                                  <li class="nav-item dropdown">
                                                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                  Log In
                                                    </a>
                                                  <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                  <a class="dropdown-item" href="#">User Login</a>
                                                  <a class="dropdown-item" href="#">Admin Login</a> </li>   
                           
                                                 	
						 </ul>
						 </div>
			 </div>
		 </div>
		 <!--/container-->
	 </div>

        <!--banner-->
        <div id="section-1" class="section">
			    <div id="top" class="callbacks_container">
			      <ul class="rslides" id="slider4">
			        <li>
			          <img src="o-TRAVEL-facebook.jpg" alt="" >
					  <div class="caption">
			     	  		<div class="header-info">
							<h2><a href="#">Your Trusted Travel Packages and Services</a></h2>
							<lable></lable>
							<h1><a href="#">Go Travel & Tourism Ltd </a></h1>
							</div>
			          </div>
			         <div class="clearfix"></div>
			    </div>	         
			   </div>
                <!--end of banner-->

            <!--about-->
        <div class="about section" id="section-2">
	  <div class="about-head text-center">
	  <h3>About Us</h3>
	  </div>
	   <div class="container">		  
		 <div class="col-md-4 about-grids">
			 <h4>Our Vision</h4>
			 <p>sehnvhserbgv lvhrirnirnvirnv;yrva;nrrrm.</p>
		 </div>
		 <div class="col-md-4 about-grids grid2">
			 <h4>Our Mission</h4>
			 <p>sj hefvsl jhnl UCBgawenlaMEXAMEAEYHVU;Y;NlM</p>
		 </div>
		 <div class="col-md-4 about-grids">
			 <h4>Safety Information</h4>
			 <p>HGVL nchwaeuaxm ;khv nl SEJHRNCger crj.</p>
		 </div>
	 </div>
</div>

<!--end of about-->




<!--top-tours-->	
<div  class="section" id="section-3">
<div id="portfolio" class="portfolio">
   <div class="top-tours-head text-center">
		  <h3>Gallery</h3>		 
		  </div>
	      <ul id="filters" class="clearfix wow bounceIn" data-wow-delay="0.4s">
			<li><span class="filter active" data-filter="app card icon logo fun">ALL</span></li>
			<li><span class="filter" data-filter="icon">Short Date Tour</span></li>
			<li><span class="filter" data-filter="fun">Long Date Tour</span></li>
	        </ul>
	     <div id="portfoliolist">
					<div class="portfolio card mix_all" data-cat="card" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
						     <img src="img/image1.jfif" class="img-responsive" alt=""/></a>
							</div>
					</div>				
					<div class="portfolio app mix_all" data-cat="app" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
						     <img src="img/images2.jfif" class="img-responsive" alt=""/></a>
                             </div>
					</div>		
					<div class="portfolio card mix_all" data-cat="card" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
						     <img src="img/images3.jfif" class="img-responsive" alt=""/></a>
							
					</div>
					</div>				
					<div class="portfolio icon mix_all" data-cat="icon" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
						     <img src="img/images4.jfif" class="img-responsive" alt=""/></a>
							 
						</div>
					</div>	
					<div class="portfolio card mix_all" data-cat="card" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
						     <img src="img/images5.jpg" class="img-responsive" alt=""/></a>
							 
						</div>
					</div>			
					<div class="portfolio fun mix_all" data-cat="fun" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
						     <img src="img/images6.jfif" class="img-responsive" alt=""/></a>
							
						</div>
			      </div>
				  <div class="portfolio fun mix_all" data-cat="fun" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
							<img src="img/images7.jfif" class="img-responsive" alt=""/></a>
							
						</div>
			      </div>
				  <div class="portfolio icon mix_all" data-cat="fun" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper wow bounceIn" data-wow-delay="0.4s">		
							<a href="#" class="b-link-stripe b-animate-go  thickbox play-icon popup-with-zoom-anim">
						     <img src="img/images8.jfif" class="img-responsive" alt=""/></a>
							 
					   </div>
			      </div>
		   <div class="clearfix"></div>	
	  </div>
</div>
</div>  
<!--end of top tour-->

<!--footer-->
<div class="fotter">	
	 <div class="container">
		 <div class="fotter-grids">
			 <div class="col-md-4 fotter-left">
			 <p style="text-align:justify"></p>
			 </div>
			 <div class="col-md-4 fotter-middle">
				 <h3></h3>
				 <div class="footer-list">
						<h3></h3>
                        <div class="footer-list">
                        </div>
             
			     </div>
			 <div class="col-md-4 fotter-right" style="padding-left:10px">
			 <h3></h3><br/>
              <div class="footer-list">
			  </div></div>
			 <div class="social-icons">
			 <a href="#"><span class="facebook"> </span></a>
			 <a href="#"><span class="twitter"> </span></a>
			 <a href="#"><span class="googleplus"> </span></a>
			 <a href="#"><span class="pinterest"> </span></a>
			 <a href="#"><span class="instagram"> </span></a>
			 </div>
			 <div class="clearfix"></div>
	     </div>
		 <div class="clearfix"></div>
	 </div>
</div>
</div>  
<div class="copyright text-right">
<p style="padding-right:100px"></p>
</div>
  
  
       
 </div>
 <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
</body>

</html>
